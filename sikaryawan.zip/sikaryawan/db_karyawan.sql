-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 23 Sep 2022 pada 12.56
-- Versi Server: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_karyawan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_gaji`
--

CREATE TABLE `tbl_gaji` (
  `id_gaji` int(4) NOT NULL,
  `id_kartetap` int(4) NOT NULL,
  `g_pokok` int(10) NOT NULL,
  `tgl_terima` date NOT NULL,
  `status_bayar` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_gaji`
--

INSERT INTO `tbl_gaji` (`id_gaji`, `id_kartetap`, `g_pokok`, `tgl_terima`, `status_bayar`) VALUES
(1, 1, 2000000, '2021-07-01', '1'),
(2, 3, 1500000, '2021-07-01', '1'),
(3, 4, 500000, '2021-07-01', '1'),
(4, 5, 500000, '2021-07-01', '1'),
(5, 6, 500000, '2021-07-01', '1'),
(6, 7, 500000, '2021-07-01', '1'),
(7, 8, 500000, '2021-07-01', '1'),
(8, 9, 500000, '2021-07-01', '1'),
(9, 10, 500000, '2021-07-01', '1'),
(10, 11, 500000, '2021-07-01', '1'),
(11, 12, 500000, '2021-07-01', '1'),
(12, 13, 500000, '2021-07-01', '1'),
(13, 14, 500000, '2021-07-01', '1'),
(14, 15, 500000, '2021-07-01', '1'),
(15, 16, 500000, '2021-07-01', '1'),
(16, 17, 500000, '2021-07-01', '1'),
(17, 18, 500000, '2021-07-01', '1'),
(18, 2, 1500000, '2021-07-01', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_jabatan`
--

CREATE TABLE `tbl_jabatan` (
  `id_jabatan` int(3) NOT NULL,
  `nama_jbtn` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_jabatan`
--

INSERT INTO `tbl_jabatan` (`id_jabatan`, `nama_jbtn`) VALUES
(1, 'Operator'),
(2, 'Kasir'),
(3, 'Tour guide'),
(4, 'Marketing');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kartetap`
--

CREATE TABLE `tbl_kartetap` (
  `id_kartetap` int(3) NOT NULL,
  `id_per` int(3) NOT NULL,
  `nama_kartetap` varchar(30) NOT NULL,
  `nama_jbtn` int(3) NOT NULL,
  `mulai_bekerja` date NOT NULL,
  `status` varchar(8) NOT NULL,
  `habis_masa_kontrak` date NOT NULL,
  `status_gaji` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_kartetap`
--

INSERT INTO `tbl_kartetap` (`id_kartetap`, `id_per`, `nama_kartetap`, `nama_jbtn`, `mulai_bekerja`, `status`, `habis_masa_kontrak`, `status_gaji`) VALUES
(1, 1, 'Riki Ardiansyah', 1, '2018-04-11', 'Tetap', '2022-04-11', '1'),
(2, 1, 'Jonni P Nainggolan', 4, '2018-04-11', 'Tetap', '2022-04-11', '1'),
(3, 1, 'Rivha Oktavhia', 2, '2018-04-11', 'Tetap', '2022-04-11', '1'),
(4, 1, 'R.Tri Prayudhi', 3, '2018-04-11', 'Tetap', '2022-04-11', '1'),
(5, 1, 'Galih Jaya Permadi', 3, '2021-04-11', 'Tetap', '2022-04-11', '1'),
(6, 1, 'M. Bima Kurniawan', 3, '2018-07-27', 'Tetap', '2022-04-11', '1'),
(7, 1, 'Putera Handika', 3, '2021-01-01', 'Kontrak', '2021-06-30', '1'),
(8, 1, 'Juliandy', 3, '2021-01-01', 'Kontrak', '2021-06-30', '1'),
(9, 1, 'Jhoni Anggariksa', 3, '2021-01-01', 'Kontrak', '2021-06-30', '1'),
(10, 1, 'Edip Suyono', 3, '2021-06-01', 'Kontrak', '2021-06-30', '1'),
(11, 1, 'Ady Chriestian A.M', 3, '2021-01-01', 'Kontrak', '2021-06-30', '1'),
(12, 1, 'Ferri Larika', 3, '2021-01-01', 'Kontrak', '2021-06-30', '1'),
(13, 1, 'Rendi Juniko', 3, '2021-04-01', 'Kontrak', '2021-09-30', '1'),
(14, 1, 'Rico Hadi Kusuma', 3, '2021-04-11', 'Kontrak', '2021-09-30', '1'),
(15, 1, 'Arlis Fajri', 3, '2021-04-01', 'Kontrak', '2021-09-30', '1'),
(16, 1, 'Piet Donario A', 3, '2021-04-01', 'Kontrak', '2021-09-30', '1'),
(17, 1, 'Fiter Akbar', 3, '2021-04-01', 'Kontrak', '2021-09-30', '1'),
(18, 1, 'Rahmat Isnoviandi', 3, '2021-04-01', 'Kontrak', '2021-09-30', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_riwayatgaji`
--

CREATE TABLE `tbl_riwayatgaji` (
  `id_riwayat` int(4) NOT NULL,
  `id_gaji` int(4) NOT NULL,
  `id_kartetap` int(3) NOT NULL,
  `tgl_terima` date NOT NULL,
  `status_gaji` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_riwayatgaji`
--

INSERT INTO `tbl_riwayatgaji` (`id_riwayat`, `id_gaji`, `id_kartetap`, `tgl_terima`, `status_gaji`) VALUES
(1, 1, 1, '2021-05-01', '1'),
(2, 2, 3, '2021-05-01', '1'),
(3, 3, 4, '2021-05-01', '1'),
(4, 4, 5, '2021-05-01', '1'),
(5, 5, 6, '2021-05-01', '1'),
(6, 6, 7, '2021-05-01', '1'),
(7, 7, 8, '2021-05-01', '1'),
(8, 8, 9, '2021-05-01', '1'),
(9, 9, 10, '2021-05-01', '1'),
(10, 10, 11, '2021-05-01', '1'),
(11, 11, 12, '2021-05-01', '1'),
(12, 12, 13, '2021-05-01', '1'),
(13, 13, 14, '2021-05-01', '1'),
(14, 14, 15, '2021-05-01', '1'),
(15, 15, 16, '2021-05-01', '1'),
(16, 16, 17, '2021-05-01', '1'),
(17, 17, 18, '2021-05-01', '1'),
(18, 18, 2, '2021-05-01', '1'),
(19, 1, 1, '2021-06-01', '1'),
(20, 2, 3, '2021-06-01', '1'),
(21, 3, 4, '2021-06-01', '1'),
(22, 4, 5, '2021-06-01', '1'),
(23, 5, 6, '2021-06-01', '1'),
(24, 6, 7, '2021-06-01', '1'),
(25, 7, 8, '2021-06-01', '1'),
(26, 8, 9, '2021-06-01', '1'),
(27, 9, 10, '2021-06-01', '1'),
(28, 10, 11, '2021-06-01', '1'),
(29, 11, 12, '2021-06-01', '1'),
(30, 12, 13, '2021-06-01', '1'),
(31, 13, 14, '2021-06-01', '1'),
(32, 14, 15, '2021-06-01', '1'),
(33, 15, 16, '2021-06-01', '1'),
(34, 16, 17, '2021-06-01', '1'),
(35, 17, 18, '2021-06-01', '1'),
(36, 18, 2, '2021-06-01', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(2) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `password`) VALUES
(1, 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_gaji`
--
ALTER TABLE `tbl_gaji`
  ADD PRIMARY KEY (`id_gaji`);

--
-- Indexes for table `tbl_jabatan`
--
ALTER TABLE `tbl_jabatan`
  ADD PRIMARY KEY (`id_jabatan`);

--
-- Indexes for table `tbl_kartetap`
--
ALTER TABLE `tbl_kartetap`
  ADD PRIMARY KEY (`id_kartetap`),
  ADD KEY `nama_jbtn` (`nama_jbtn`);

--
-- Indexes for table `tbl_riwayatgaji`
--
ALTER TABLE `tbl_riwayatgaji`
  ADD PRIMARY KEY (`id_riwayat`),
  ADD KEY `id_gaji` (`id_gaji`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_gaji`
--
ALTER TABLE `tbl_gaji`
  MODIFY `id_gaji` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_jabatan`
--
ALTER TABLE `tbl_jabatan`
  MODIFY `id_jabatan` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_kartetap`
--
ALTER TABLE `tbl_kartetap`
  MODIFY `id_kartetap` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_riwayatgaji`
--
ALTER TABLE `tbl_riwayatgaji`
  MODIFY `id_riwayat` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tbl_kartetap`
--
ALTER TABLE `tbl_kartetap`
  ADD CONSTRAINT `a` FOREIGN KEY (`nama_jbtn`) REFERENCES `tbl_jabatan` (`id_jabatan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_riwayatgaji`
--
ALTER TABLE `tbl_riwayatgaji`
  ADD CONSTRAINT `tbl_riwayatgaji_ibfk_1` FOREIGN KEY (`id_gaji`) REFERENCES `tbl_gaji` (`id_gaji`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
