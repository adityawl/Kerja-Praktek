<html>

<head>
    <title>Halaman Login SI Karyawan</title>
    <link rel="shorcut icon" type="image/x-icon" href="<?= base_url(); ?>assets/login/logotkr.jpg">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/login/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<body>
    <div class="loginbox">
        <img src="<?php echo base_url(); ?>assets/images/logotkr.jpg" class="avatar">
        <h4 style="text-align: center; color : blue">Silahkan Login</h4><br>

        <form method="post" action="<?php echo base_url(); ?>index.php/login/getlogin">

            <p style="color: blue">Username</p>
            <input style="color: black" type="text" id="username" name="username" placeholder="Masukkan Username" required>
            <p style="color: blue">Password</p>
            <input style="color: black" type="password" id="password" name="password" placeholder="Masukkan Password" required>

            <input type="submit" name="" value="Login">
            <?php echo $this->session->flashdata('info'); ?>

        </form>


    </div>
</body>
</head>

</html>