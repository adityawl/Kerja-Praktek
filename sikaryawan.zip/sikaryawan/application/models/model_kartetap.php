<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_kartetap extends CI_Model
{

	public function listing()
	{
		$this->db->select('tbl_kartetap.id_kartetap,nama_kartetap,tbl_jabatan.nama_jbtn,tbl_kartetap.mulai_bekerja,tbl_kartetap.status,tbl_kartetap.habis_masa_kontrak,tbl_kartetap.status_gaji,tbl_jabatan.id_jabatan,tbl_kartetap.nama_jbtn as jabatan')
			->join('tbl_jabatan', 'tbl_jabatan.id_jabatan=tbl_kartetap.nama_jbtn')
			->where('id_per', '1');
		return $this->db->get('tbl_kartetap')->result();
	}

	public function listing_k()
	{
		$this->db->select('tbl_kartetap.id_kartetap,nama_kartetap,tbl_jabatan.nama_jbtn,tbl_kartetap.mulai_bekerja,tbl_kartetap.status,tbl_kartetap.habis_masa_kontrak,tbl_kartetap.status_gaji,tbl_jabatan.id_jabatan,tbl_kartetap.nama_jbtn as jabatan')
			->join('tbl_jabatan', 'tbl_jabatan.id_jabatan=tbl_kartetap.nama_jbtn')
			->where('id_per', '2');
		return $this->db->get('tbl_kartetap')->result();
	}

	public function detail($id_kartetap)
	{
		$this->db->from('tbl_kartetap');
		$this->db->where('id_kartetap', $id_kartetap);
		$query = $this->db->get();

		return $query;
	}

	public function getjabatan()
	{
		$query = $this->db->query('SELECT * FROM tbl_jabatan ORDER BY nama_jbtn');
		return $query->result_array();
	}

	public function simpan($tetap)
	{
		$this->db->insert('tbl_kartetap', $tetap);
		return $this->db->insert_id();
	}

	public function simpan_gaji($gaji)
	{
		$this->db->insert('tbl_gaji', $gaji);
		return $this->db->insert_id();
	}

	public function edit($where, $tetap, $table)
	{
		$this->db->where($where);
		$this->db->update($table, $tetap);
	}

	public function perpanjang($where, $tetap, $table)
	{
		$this->db->where($where);
		$this->db->update($table, $tetap);
	}

	public function hapus($data)
	{
		$this->db->where('id_kartetap', $data['id_kartetap']);
		$this->db->delete('tbl_kartetap');
	}

	public function hapus_gaji($data)
	{
		$this->db->where('id_kartetap', $data['id_kartetap']);
		$this->db->delete('tbl_gaji');
	}
}

/* End of file model_kartetap.php */
/* Location: ./application/models/model_kartetap.php */
