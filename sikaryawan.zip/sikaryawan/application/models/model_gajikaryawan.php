<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_gajikaryawan extends CI_Model
{

    public function getdata()
    {

        $query = "SELECT tbl_gaji.*, tbl_kartetap.nama_kartetap, tbl_kartetap.id_per, tbl_kartetap.mulai_bekerja, tbl_kartetap.habis_masa_kontrak
                 FROM tbl_gaji JOIN tbl_kartetap
                 ON tbl_gaji.id_kartetap = tbl_kartetap.id_kartetap
                 WHERE tbl_kartetap.id_per = '1'
                ";

        return $this->db->query($query)->result_array();
    }

    public function getdata_k()
    {

        $query = "SELECT tbl_gaji.*, tbl_kartetap.nama_kartetap, tbl_kartetap.id_per, tbl_kartetap.mulai_bekerja, tbl_kartetap.habis_masa_kontrak
                 FROM tbl_gaji JOIN tbl_kartetap
                 ON tbl_gaji.id_kartetap = tbl_kartetap.id_kartetap
                 WHERE tbl_kartetap.id_per = '2'
                ";

        return $this->db->query($query)->result_array();
    }

    public function getdatabyid($id_gaji)
    {

        $query = "SELECT tbl_gaji.*, tbl_kartetap.nama_kartetap, tbl_kartetap.habis_masa_kontrak
                 FROM tbl_gaji JOIN tbl_kartetap
                 ON tbl_gaji.id_kartetap = tbl_kartetap.id_kartetap
                 WHERE id_gaji = '$id_gaji'
                ";

        return $this->db->query($query)->result_array();
    }

    public function getriwayat()
    {

        $query = "SELECT tbl_riwayatgaji.*, tbl_gaji.id_gaji, tbl_kartetap.id_per, tbl_kartetap.nama_kartetap, tbl_kartetap.habis_masa_kontrak
                 FROM tbl_riwayatgaji 
                 JOIN tbl_gaji ON tbl_riwayatgaji.id_gaji = tbl_gaji.id_gaji
                 JOIN tbl_kartetap ON tbl_riwayatgaji.id_kartetap = tbl_kartetap.id_kartetap
                 WHERE tbl_kartetap.id_per = '1'
                 GROUP BY id_kartetap
                ";

        return $this->db->query($query)->result_array();
    }

    public function getriwayat_k()
    {

        $query = "SELECT tbl_riwayatgaji.*, tbl_gaji.id_gaji, tbl_kartetap.id_per, tbl_kartetap.nama_kartetap, tbl_kartetap.habis_masa_kontrak
                 FROM tbl_riwayatgaji 
                 JOIN tbl_gaji ON tbl_riwayatgaji.id_gaji = tbl_gaji.id_gaji
                 JOIN tbl_kartetap ON tbl_riwayatgaji.id_kartetap = tbl_kartetap.id_kartetap
                 WHERE tbl_kartetap.id_per = '2'
                 GROUP BY id_kartetap
                ";

        return $this->db->query($query)->result_array();
    }

    public function detail($id_gaji)
    {
        $query = "SELECT tbl_riwayatgaji.*, tbl_gaji.id_gaji, tbl_gaji.g_pokok, tbl_kartetap.nama_kartetap
                 FROM tbl_riwayatgaji 
                 JOIN tbl_gaji ON tbl_riwayatgaji.id_gaji = tbl_gaji.id_gaji
                 JOIN tbl_kartetap ON tbl_riwayatgaji.id_kartetap = tbl_kartetap.id_kartetap
                 WHERE tbl_riwayatgaji.id_gaji = '$id_gaji'
                ";

        return $this->db->query($query)->result_array();
    }
}
