<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
			<a href="#" class="fa fa-times"></a>
		</div>

		<h2 class="panel-title"><?php echo $judul; ?></h2>
	</header>
	<div class="panel-body">

		<div class="flash-data" data-flashdata="<?php echo $this->session->flashdata('info'); ?>"></div>

		<table class="table table-bordered table-striped mb-none" id="datatable-tabletools" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
			<thead>
				<tr>
					<th>No</th>
					<th>ID Gaji</th>
					<th>Nama Karyawan</th>
					<th>Tanggal Terima</th>
					<th>Status</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php $i = 1; ?>
				<?php foreach ($data as $dt) :
					// $tgl = date('Y-m-d');
					// 		$tgl_mulai = $gj['mulai_bekerja'];
					// 		$tgl_terima = $gj['tgl_terima'];
					// 		$tgl_terima2 = date('Y-m-d', strtotime('+1 months', strtotime($tgl_terima)));
					// 30 hari setelah tanggal mulai kerja
					?>
					<tr>
						<td><?= $i; ?></td>
						<td><?= $dt['id_gaji']; ?></td>
						<td><?= $dt['nama_kartetap']; ?></td>
						<td><?= $dt['tgl_terima']; ?></td>
						<td>
							<?php if ($dt['status_gaji'] == 1) {
								echo '<span class="label label-success">Sudah dibayar</span>';
							}
							?>
						</td>
						<td>
							<a href="<?= base_url(); ?>index.php/riwayat_gaji/detail/<?= $dt['id_gaji']; ?>" class="mb-xs mt-xs mr-xs btn btn-xs btn-warning"><i class="fa fa-fw fa-search"></i> Detail</a>
						</td>
					</tr>

					<?php $i++; ?>
				<?php endforeach; ?>

			</tbody>
		</table>
	</div>
</section>