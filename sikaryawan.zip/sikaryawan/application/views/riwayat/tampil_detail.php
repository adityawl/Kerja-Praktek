<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
			<a href="#" class="fa fa-times"></a>
		</div>

		<h2 class="panel-title"><?php echo $sub_judul; ?></h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none" id="datatable-tabletoolss" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
			<thead>
				<tr>
					<th>No</th>
					<th>Nama Karyawan</th>
					<th>Tanggal Terima</th>
					<th>Jumlah Gaji</th>
					<th>Status Pembayaran</th>
				</tr>
			</thead>
			<tbody>
				<?php $i = 1; ?>
				<?php foreach ($detail as $dt) : ?>
					<tr>
						<td><?= $i; ?></td>
						<td><?= $dt['nama_kartetap']; ?></td>
						<td><?= $dt['tgl_terima']; ?></td>
						<td>Rp. <?= number_format($dt['g_pokok'], 0, ',', '.'); ?>,-</td>
						<td>
							<?php if ($dt['status_gaji'] == 1) {
								echo '<span class="label label-success">Sudah dibayar</span>';
							}
							?>
						</td>
					</tr>

					<?php $i++; ?>
				<?php endforeach; ?>

			</tbody>
		</table>
	</div>
</section>