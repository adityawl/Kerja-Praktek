<!-- Vendor -->
<script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/nanoscroller/nanoscroller.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/magnific-popup/magnific-popup.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

<!-- Specific Page Vendor -->
<script src="<?php echo base_url(); ?><?php echo base_url(); ?>assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-appear/jquery.appear.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/flot/jquery.flot.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/flot/jquery.flot.pie.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/flot/jquery.flot.categories.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/flot/jquery.flot.resize.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/raphael/raphael.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/morris/morris.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/gauge/gauge.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/snap-svg/snap.svg.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/liquid-meter/liquid.meter.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jqvmap/jquery.vmap.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/select2/select2.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>

<!-- Theme Base, Components and Settings -->
<script src="<?php echo base_url(); ?>assets/javascripts/theme.js"></script>

<!-- Theme Custom -->
<script src="<?php echo base_url(); ?>assets/javascripts/theme.custom.js"></script>

<!-- Theme Initialization Files -->
<script src="<?php echo base_url(); ?>assets/javascripts/theme.init.js"></script>

<!-- Examples -->
<script src="<?php echo base_url(); ?>assets/javascripts/dashboard/examples.dashboard.js"></script>

<!-- Sweet Alert -->
<script src="<?php echo base_url(); ?>assets/js/sweetalert2.all.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/scriptswal.js"></script>

<!-- Select2 -->
<script src="<?php echo base_url(); ?>assets/select2/dist/js/select2.full.min.js"></script>


<script type="text/javascript">
	$(".form-group").keyup(function() {
		var a = parseInt($("#g_pokok").val());
		var b = parseInt($("#insentif").val());
		var jumlah = a + b ;
		$("#jmlh_bersih").val(jumlah);
	});
</script>

<script type="text/javascript">
	$('.select2').select2();
</script>

<!-- Tabel Data Karyawan -->

<script type="text/javascript">
	(function($) {

		'use strict';

		var datatableInit = function() {
			var $table = $('#tabel_kartep');

			// format function for row details

			// insert the expand/collapse column
			var th = document.createElement('th');
			var td = document.createElement('td');
			td.innerHTML = '<i data-toggle class="fa fa-plus-circle text-primary h4 m-none" style="cursor: pointer;"></i>';
			td.className = "text-center";

			$table
				.find('thead tr').each(function() {
					this.insertBefore(th, this.childNodes[0]);
				});

			$table
				.find('tbody tr').each(function() {
					this.insertBefore(td.cloneNode(true), this.childNodes[0]);
				});

			// initialize
			var datatable = $table.dataTable({
				aoColumnDefs: [{
					bSortable: false,
					aTargets: [0]
				}],
				aaSorting: [
					[1, 'asc']
				]
			});

			// add a listener
			$table.on('click', 'i[data-toggle]', function() {
				var $this = $(this),
					tr = $(this).closest('tr').get(0);

				if (datatable.fnIsOpen(tr)) {
					$this.removeClass('fa-minus-circle').addClass('fa-plus-circle');
					datatable.fnClose(tr);
				} else {
					$this.removeClass('fa-plus-circle').addClass('fa-minus-circle');
					datatable.fnOpen(tr, fnFormatDetails(datatable, tr), 'details');
				}
			});
		};

		$(function() {
			datatableInit();
		});

	}).apply(this, [jQuery]);
</script>


<!-- Tabel Gaji Karyawan -->

<script type="text/javascript">
	(function($) {

		'use strict';

		var datatableInit = function() {
			var $table = $('#tabel_gaji');

			// format function for row details
			

			// insert the expand/collapse column
			var th = document.createElement('th');
			var td = document.createElement('td');
			td.innerHTML = '<i data-toggle class="fa fa-plus-circle text-primary h4 m-none" style="cursor: pointer;"></i>';
			td.className = "text-center";

			$table
				.find('thead tr').each(function() {
					this.insertBefore(th, this.childNodes[0]);
				});

			$table
				.find('tbody tr').each(function() {
					this.insertBefore(td.cloneNode(true), this.childNodes[0]);
				});

			// initialize
			var datatable = $table.dataTable({
				aoColumnDefs: [{
					bSortable: false,
					aTargets: [0]
				}],
				aaSorting: [
					[1, 'asc']
				]
			});

			// add a listener
			$table.on('click', 'i[data-toggle]', function() {
				var $this = $(this),
					tr = $(this).closest('tr').get(0);

				if (datatable.fnIsOpen(tr)) {
					$this.removeClass('fa-minus-circle').addClass('fa-plus-circle');
					datatable.fnClose(tr);
				} else {
					$this.removeClass('fa-plus-circle').addClass('fa-minus-circle');
					datatable.fnOpen(tr, fnFormatDetails(datatable, tr), 'details');
				}
			});
		};

		$(function() {
			datatableInit();
		});

	}).apply(this, [jQuery]);
</script>

<!-- TABEL RIWAYAT GAJI -->
<script type="text/javascript">
	(function($) {

		'use strict';

		var datatableInit = function() {
			var $table = $('#datatable-tabletools');

			$table.dataTable({
				sDom: "<'text-right mb-md'T>" + $.fn.dataTable.defaults.sDom,
				oTableTools: {
					sSwfPath: $table.data('swf-path'),
					aButtons: [{
							sExtends: 'pdf',
							sButtonText: 'PDF'
						},
						{
							sExtends: 'csv',
							sButtonText: 'CSV'
						},
						{
							sExtends: 'xls',
							sButtonText: 'Excel'
						}
					]
				}
			});

		};

		$(function() {
			datatableInit();
		});

	}).apply(this, [jQuery]);
</script>


<!-- TABEL DETAIL GAJI -->
<script type="text/javascript">
	(function($) {

		'use strict';

		var datatableInit = function() {
			var $table = $('#datatable-tabletoolss');

			$table.dataTable({
				sDom: "<'text-right mb-md'T>" + $.fn.dataTable.defaults.sDom,
				oTableTools: {
					sSwfPath: $table.data('swf-path'),
					aButtons: [{
							sExtends: 'pdf',
							sButtonText: 'PDF'
						},
						{
							sExtends: 'csv',
							sButtonText: 'CSV'
						},
						{
							sExtends: 'xls',
							sButtonText: 'Excel'
						},
						{
							sExtends: 'print',
							sButtonText: 'Print',
							sInfo: 'Please press CTR+P to print or ESC to quit'
						}
					]
				}
			});

		};

		$(function() {
			datatableInit();
		});

	}).apply(this, [jQuery]);
</script>

</body>

</html>