<!-- start: sidebar -->
<aside id="sidebar-left" class="sidebar-left">

	<div class="sidebar-header">
		<div class="sidebar-title">
			<span style="font-family: Arial, Helvetica, sans-serif ; color:white">Menu Utama</span>
		</div>
		<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
			<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
		</div>
	</div>

	<div class="nano">
		<div class="nano-content">
			<nav id="menu" class="nav-main" role="navigation">
				<ul class="nav nav-main">

					<li class="nav-link <?= $this->uri->segment(1) == 'beranda' || $this->uri->segment(1) == '' ? 'nav-active' : '' ?>">
						<a href="<?php echo base_url(); ?>index.php/beranda">
							<i class="fa fa-home" aria-hidden="true"></i>
							<span>Beranda</span>
						</a>
					</li>
					<li class="nav-link <?= $this->uri->segment(1) == 'kartetap' ? 'nav-active' : '' ?>">
						<a href="<?php echo base_url(); ?>index.php/kartetap">
							<i class="fa fa-users"></i>Data Karyawan
						</a>
					</li>
					<li class="nav-link <?= $this->uri->segment(1) == 'gaji_karyawan' ? 'nav-active' : '' ?>">
						<a href="<?php echo base_url(); ?>index.php/gaji_karyawan">
							<i class="fa fa-money"></i>Data Gaji Karyawan
						</a>
					</li>
					<li class="nav-link <?= $this->uri->segment(1) == 'riwayat_gaji' ? 'nav-active' : '' ?>">
						<a href="<?php echo base_url(); ?>index.php/riwayat_gaji">
							<i class="fa fa-list-alt"></i>Riwayat Gaji Karyawan
						</a>
					</li>
				</ul>
			</nav>

		</div>

	</div>

</aside>
<!-- end: sidebar -->