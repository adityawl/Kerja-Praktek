<div class="row">
	<div class="col-md-12">

		<section class="panel">
			<header class="panel-heading">

				<div class="panel-actions">
					<a href="#" class="fa fa-caret-down"></a>
				</div>

				<h2 class="panel-title">Tambah Karyawan</h2>
			</header>


			<form class="form-horizontal form-bordered" method="POST" action="<?php echo base_url(); ?>index.php/kartetap/save">

				<div class="panel-body">
					<div class="row">

						<div class="col-sm-6">

							<div class="form-group">
								<label class="col-md-4 control-label">Nama Perusahaan</label>
								<div class="col-md-7">
									<input type="text" class="form-control" value="CV.TOBO KITO MANDIRI" readonly>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-4 control-label">Nama Karyawan</label>
								<div class="col-md-7">
									<input type="text" class="form-control" id="namakar" name='namakar' required>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-4 control-label" for="inputDefault">Jabatan</label>
								<div class="col-md-7">
									<select class="form-control select2" id="jabatan" name="jabatan" required>
										<option value="0"> Pilih Jabatan </option>
										<?php foreach ($jabatan as $jbt) { ?>

											<option value="<?php echo $jbt['id_jabatan'] ?>"><?php echo $jbt['nama_jbtn'] ?></option>

										<?php } ?>
									</select>
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-md-4 control-label" for="inputDefault">Mulai Bekerja</label>
								<div class="col-md-5">
									<input type="date" class="form-control" id="mulaibekerja" name='mulaibekerja' required>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-4 control-label" for="inputDefault">Status</label>
								<div class="col-md-5">
									<select class="form-control" id='status' name='status' required>
										<option value="0"> Pilih Status </option>
										<option> Tetap </option>
										<option> Kontrak </option>
									</select>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-4 control-label" for="inputDefault">Habis Masa Kontrak</label>
								<div class="col-md-5">
									<input type="date" class="form-control" id="habis" name='habis' required>
									<input type="hidden" class="form-control" id="status_gaji" name='status_gaji' value="0">
								</div>
							</div>

						</div>

						<div class="form-group">
							<label class="col-md-10 control-label"></label>
							<div class="col-sm-6">
								<br>
								&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
								<button class="btn btn-success" name="submit" type="submit">
									<i class="fa fa-save"></i> Simpan</button>

								<a href="<?php echo base_url(); ?>index.php/kartetap" class="btn btn-danger" name="reset" type="reset">
									<i class="fa fa-times"></i> Kembali</a>
							</div>

						</div>

					</div>
				</div>

			</form>

		</section>
	</div>
</div>