<!-- start: page -->
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
			<a href="#" class="fa fa-times"></a>
		</div>
		<h2 class="panel-title"><?= $sub_judul; ?></h2>
	</header>

	<div class="panel-body">

		<div class="flash-data" data-flashdata="<?php echo $this->session->flashdata('info'); ?>"></div>

		<?php if ($this->session->flashdata('info')) : ?>



		<?php endif; ?>

		<a href="<?php echo base_url(); ?>index.php/kartetap/tambah" class="btn btn-default btn-success">
			<i class="glyphicon glyphicon-plus"></i><span> Tambah</span> </a>
		<br><br>
		<table class="table table-bordered table-striped mb-none" id="tabel_kartep">
			<thead>
				<tr>
					<th>No</th>
					<th>Nama</th>
					<th>Nama Jabatan</th>
					<th>Mulai Bekerja</th>
					<th>Status</th>
					<th>Habis Masa Kontrak</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php $no = 1;
				foreach ($kartep as $user) {
					$date = date_create($user->habis_masa_kontrak);
					date_add($date, date_interval_create_from_date_string("-1 Month"));
					$today = new datetime();
					?>
				<tr>
					<?php if (date_format($today, "Y-m-d") >= date_format($date, "Y-m-d")) { ?>
					<td class="text-danger"><?php echo $no++ ?></td>
					<td class="text-danger"><?php echo $user->nama_kartetap ?></td>
					<td class="text-danger"><?php echo $user->nama_jbtn ?></td>
					<td class="text-danger"><?php echo $user->mulai_bekerja ?></td>
					<td class="text-danger"><?php echo $user->status ?></td>
					<td class="text-danger"><?php echo $user->habis_masa_kontrak ?></td>
					<td>
						<a title="Edit Data" href="<?php echo base_url(); ?>index.php/kartetap/edit/<?php echo $user->id_kartetap ?>" class="btn btn-primary"><i class="fa fa-pencil"></i></a>

						<a title="Tambah Gaji" href="<?php echo base_url(); ?>index.php/kartetap/tambah_gaji/<?php echo $user->id_kartetap ?>" class="btn btn-warning" <?php if ($user->status_gaji != '0') {
																																													echo "";
																																												} ?>><i class="fa fa-money"></i></a>

						<a title="Hapus Data" href="<?php echo base_url(); ?>index.php/kartetap/hapus/<?php echo $user->id_kartetap ?>" class="btn btn-danger tombol-hapus"><i class="fa fa-trash-o"></i></a>

						<a title="Perpanjang" href="<?php echo base_url(); ?>index.php/kartetap/perpanjang/<?php echo $user->id_kartetap ?>" class="btn btn-success"><i class="fa fa-undo"></i></a>


					</td>
					<?php } else { ?>
					<td><?php echo $no++ ?></td>
					<td><?php echo $user->nama_kartetap ?></td>
					<td><?php echo $user->nama_jbtn ?></td>
					<td><?php echo $user->mulai_bekerja ?></td>
					<td><?php echo $user->status ?></td>
					<td><?php echo $user->habis_masa_kontrak ?></td>
					<td>
						<a title="Edit Data" href="<?php echo base_url(); ?>index.php/kartetap/edit/<?php echo $user->id_kartetap ?>" class="btn btn-primary"><i class="fa fa-pencil"></i></a>

						<a title="Tambah Gaji" href="<?php echo base_url(); ?>index.php/kartetap/tambah_gaji/<?php echo $user->id_kartetap ?>" class="btn btn-warning" <?php if ($user->status_gaji != '0') {
																																													echo "disabled";
																																												} ?>><i class="fa fa-money"></i></a>

						<a title="Hapus Data" href="<?php echo base_url(); ?>index.php/kartetap/hapus/<?php echo $user->id_kartetap ?>" class="btn btn-danger tombol-hapus"><i class="fa fa-trash-o"></i></a>
					</td>
					<?php } ?>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
</section>