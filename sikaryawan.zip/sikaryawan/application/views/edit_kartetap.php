<div class="row">
	<div class="col-lg-12">
		<section class="panel">
			<header class="panel-heading">

				<div class="panel-actions">
					<a href="#" class="fa fa-caret-down"></a>
				</div>

				<h2 class="panel-title"><?= $sub_judul; ?></h2>
			</header>

			<div class="panel-body">

				<?php foreach ($data3->result() as $row) { ?>

					<form class="form-horizontal form-bordered" method="POST" action="<?php echo base_url(); ?>index.php/kartetap/save1">
						<div class="form-group">
							<label class="col-md-3 control-label">Nama Karyawan</label>
							<div class="col-md-5">
								<input type="hidden" name="id_kartetap" value="<?php echo $row->id_kartetap ?>">
								<input type="text" class="form-control" id="namakar" name='namakar' value="<?php echo $row->nama_kartetap  ?>" required>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label" for="inputDefault">Jabatan</label>
							<div class="col-md-3">
								<select class="form-control select2" id="jabatan" name="jabatan" required>
									<option value="0"> Pilih Jabatan </option>
									<?php foreach ($data2 as $jbt) { ?>

										<option value="<?php echo $jbt['id_jabatan'] ?>"><?php echo $jbt['nama_jbtn'] ?></option>

									<?php } ?>
								</select>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label" for="inputDefault">Mulai Bekerja</label>
							<div class="col-md-3">
								<input type="date" class="form-control" id="mulaibekerja" name='mulaibekerja' value="<?php echo $row->mulai_bekerja ?>" required>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label" for="inputDefault">Status</label>
							<div class="col-md-3">
								<select class="form-control" id='status' name='status' required>
									<option value="0"> Pilih Status </option>
									<option> Tetap </option>
									<option> Kontrak </option>
								</select>
							</div>
						</div>

			


						<div class="form-group">
							<label class="col-md-2 control-label"></label>
							<div class="col-md-5">
								<button class="btn btn-success" name="submit" type="submit">
									<i class="fa fa-save"></i> Simpan</button>

								<a class="btn btn-danger" name="reset" href="<?php echo base_url(); ?>index.php/kartetap">
									<i class="fa fa-times"></i> Kembali</a>
							</div>

						</div>
					</form>
				<?php } ?>
			</div>
		</section>
	</div>
</div>