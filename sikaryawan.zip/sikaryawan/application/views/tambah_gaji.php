
<div class="row">
	<div class="col-lg-12">
		<section class="panel">
			<header class="panel-heading">

				<div class="panel-actions">
					<a href="#" class="fa fa-caret-down"></a>
				</div>

				<h2 class="panel-title"><?= $sub_judul; ?></h2>
			</header>

			<div class="panel-body">

				<?php foreach ($data3->result() as $row) { ?>

				<form class="form-horizontal form-bordered" method="POST" action="<?php echo base_url(); ?>index.php/kartetap/tambahgaji">
					<div class="form-group">
						<label class="col-md-3 control-label">Nama Karyawan</label>
						<div class="col-md-5">
							<input type="hidden" name="id_kartetap" value="<?php echo $row->id_kartetap ?>">
							<input type="text" readonly class="form-control" id="namakar" name='namakar' value="<?php echo $row->nama_kartetap  ?>" required>
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label">Mulai Kerja</label>
						<div class="col-md-3">
							<input type="text" class="form-control" value="<?php echo $row->mulai_bekerja ?>" readonly>
						</div>

						<label class="col-md-2 control-label">Tanggal Terima</label>
						<div class="col-md-3">
							<input type="date" class="form-control" id="tgl_terima" name='tgl_terima'>
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label" for="inputDefault">Jabatan</label>
						<div class="col-md-3">
							<?php foreach ($data2 as $jbt) : ?>

							<?php if ($jbt['id_jabatan'] == $row->nama_jbtn) : ?>

							<input type="text" class="form-control" value="<?php echo $jbt['nama_jbtn'] ?>" readonly>

							<?php endif; ?>

							<?php endforeach; ?>
							</select>
						</div>
					</div>

					<div class="form-group">

						<label class="col-md-3 control-label">Gaji Pokok</label>
						<div class="col-md-3">
							<div class="input-group mb-md">
								<span class="input-group-addon">
									<i class="fa fa-money"> RP</i>
								</span>
								<?php foreach ($data2 as $jbt) : ?>

							<?php if ($jbt['id_jabatan'] == $row->nama_jbtn) : ?>

								<?php if($jbt['id_jabatan'] == 1){
							
									$gaji = number_format(2000000, 0, ".", ".");
									$ga = 2000000;
								}elseif($jbt['id_jabatan'] == 2) {
									$gaji = number_format(1500000, 0, ".", ".");
									$ga = 1500000;
								}elseif($jbt['id_jabatan'] == 3) {
									$gaji = number_format(500000, 0, ".", ".");
									$ga = 500000;
								}elseif($jbt['id_jabatan'] == 4) {
									$gaji = number_format(1500000, 0, ".", ".");
									$ga = 1500000;
								} ?>
								<input type="text" class="form-control" id='g_pokok' value="<?= $gaji; ?>" name='g_pokokk' readonly >
								<?php endif; ?>

							<?php endforeach; ?>
							</div>
						</div>
						</div>

					<input type="hidden" name="g_pokok" value="<?= $ga; ?>">


					<div class="form-group">
						<label class="col-md-2 control-label"></label>
						<div class="col-md-5">
							<button class="btn btn-success" name="submit" type="submit">
								<i class="fa fa-save"></i> Simpan</button>

							<a href="<?= base_url('kartetap'); ?>" class="btn btn-danger" name="reset" type="reset">
								<i class="fa fa-times"></i> Kembali</a>
						</div>

					</div>
				</form>
				<?php } ?>
			</div>
		</section>
	</div>
</div>