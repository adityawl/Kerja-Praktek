<div class="row">
	<div class="col-lg-12">
		<section class="panel">
			<header class="panel-heading">

				<div class="panel-actions">
					<a href="#" class="fa fa-caret-down"></a>
				</div>

				<h2 class="panel-title"><?= $sub_judul; ?></h2>
			</header>

			<div class="panel-body">

				<?php foreach ($data3->result() as $row) { ?>

					<form class="form-horizontal form-bordered" method="POST" action="<?php echo base_url(); ?>index.php/kartetap/save_perpanjang">
						<div class="form-group">
							<label class="col-md-3 control-label">Nama Karyawan</label>
							<div class="col-md-5">
								<input type="hidden" name="id_kartetap" value="<?php echo $row->id_kartetap ?>">
								<input type="text" class="form-control" id="namakar" name='namakar' value="<?php echo $row->nama_kartetap  ?>" required readonly>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label" for="inputDefault">Mulai Bekerja</label>
							<div class="col-md-3">
								<input type="date" class="form-control" id="mulaibekerja" name='mulaibekerja' value="<?php echo $row->mulai_bekerja ?>" required readonly>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label" for="inputDefault">Habis Masa Kontrak</label>
							<div class="col-md-3">
								<input type="date" class="form-control" id="habis1" name='habis1' value="<?php echo $row->habis_masa_kontrak ?>" required readonly>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label" for="inputDefault">Masa Kontrak Baru</label>
							<div class="col-md-3">
								<input type="date" class="form-control" id="habis" name='habis' required>
							</div>
						</div>


						<div class="form-group">
							<label class="col-md-2 control-label"></label>
							<div class="col-md-5">
								<button class="btn btn-success" name="submit" type="submit">
									<i class="fa fa-save"></i> Simpan</button>

								<a class="btn btn-danger" name="reset" href="<?php echo base_url(); ?>index.php/kartetap">
									<i class="fa fa-times"></i> Kembali</a>
							</div>

						</div>
					</form>
				<?php } ?>
			</div>
		</section>
	</div>
</div>