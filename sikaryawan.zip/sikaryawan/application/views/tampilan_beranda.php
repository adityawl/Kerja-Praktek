	<?php $this->load->view('layout/header'); ?>

	<body>
		<section class="body">

			<?php $this->load->view('tampilan_header'); ?>

			<div class="inner-wrapper">

				<?php $this->load->view('tampilan_menu'); ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2><?php echo $judul;  ?></h2>

						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span><?php echo $sub_judul; ?></span></li>
							</ol>

							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<?php $this->load->view($content); ?>

				</section>
			</div>
		</section>

		<footer class="footer">
			<span>Copyright &copy; 2021 | Kerja Praktik | Sistem Informasi Penggajian</span>
		</footer>

		<aside id="sidebar-right" class="sidebar-right">
			<div class="nano">
				<div class="nano-content">
					<a href="#" class="mobile-close visible-xs">
						Collapse <i class="fa fa-chevron-right"></i>
					</a>

					<div class="sidebar-right-wrapper">

						<div class="sidebar-widget widget-calendar">
							<h6>Upcoming Tasks</h6>
							<div data-plugin-datepicker data-plugin-skin="dark"></div>

							<ul>
								<li>
									<time datetime="2014-04-19T00:00+00:00">04/19/2014</time>
									<span>Company Meeting</span>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</aside>
		</section>

		<?php $this->load->view('layout/footer'); ?>