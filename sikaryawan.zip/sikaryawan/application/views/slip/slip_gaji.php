<?php foreach ($data as $dt) : ?>

	<section class="panel">
		<div class="panel-body">
			<div class="invoice">
				<header class="clearfix">
					<div class="row">
						<div class="col-sm-4 mt-md">
							<h2 class="h2 mt-none mb-sm text-dark text-bold">SLIP GAJI</h2>
							<h4 class="h4 m-none text-dark text-bold"><?php echo $dt['nama_kartetap']; ?></h4>
						</div>
						<div class="col-sm-8 text-right mt-md mb-md">
							<address class="ib mr-xlg">
								<br />
								JL.Bandar Raya no 40A rt 002 rw 001 kel. Rawa makmur
								<br />
								Telp. +6285273550666
								<br />
								EMAIL :Tobokitomandiri@gmail.com
							</address>
							<div class="ib">
								<img src="<?php echo base_url(); ?>assets/images/logotkr.jpg" alt="OKLER Themes" />
							</div>
						</div>
					</div>
				</header>
				<div class="bill-info">
					<div class="row">
						<div class="col-md-6">
							<div class="bill-to">
								<p class="h5 mb-xs text-dark text-semibold">Kepada</p>
								<address>
									<h5>Yth.</h5>
									<h5>Tn/Ny. <?php echo $dt['nama_kartetap']; ?></h5>
								</address>
							</div>
						</div>
						<div class="col-md-6">
							<div class="bill-data text-right">
								<p class="mb-none">
									<span class="text-dark">Tanggal :</span>
									<span class="value"><strong><?php echo date('d-M-Y'); ?></strong></span>
								</p>
							</div>
						</div>
					</div>
				</div>

				<div class="table-responsive">
					<table class="table invoice-items">
						<thead>
							<tr class="h5 text-dark">
								<th>Nama</th>
								<th>Gaji Pokok</th>
								<th>Jumlah Terima</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?= $dt['nama_kartetap']; ?></td>
								<td>Rp. <?= number_format($dt['g_pokok'], 0, ',', '.'); ?>,-</td>
								<td>Rp. <?= number_format($dt['g_pokok'], 0, ',', '.'); ?>,-</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div class="invoice-summary">
					<div class="row">
						<div class="col-sm-6 col-sm-offset-6">
							<table class="table h5 text-dark">
								<tbody>
									<tr class="h4">
										<td colspan="2">Total di Terima</td>
										<td class="text-left"> Rp. <?= number_format($dt['g_pokok'], 0, ',', '.'); ?>,-</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			<br>

			<div class="text-right mr-lg">
				<a href="<?php echo base_url(); ?>index.php/gaji_karyawan/print/<?php echo $dt['id_gaji']; ?>" target="_blank" class="btn btn-primary ml-sm"><i class="fa fa-print"></i> Print</a>
			</div>
		</div>
	</section>

<?php endforeach; ?>