<!-- start: page -->
<section class="panel panel-horizontal">
	<header class="panel-heading bg-white">
		<div class="panel-heading-icon bg-primary mt-sm">
			<i class="fa fa-user"></i>
		</div>
	</header>
	<div class="panel-body p-lg">
		<h3 class="text-semibold mt-sm">Selamat Datang Admin</h3>
		<p>Di Sistem Informasi Penggajian CV.TOBO KITO RAFTING</p>
	</div>
</section>

<div class="row">
	<div class="col-md-6 col-xl-12">
		<section class="panel">
			<div class="panel-body bg-primary">
				<div class="widget-summary">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon">
							<i class="fa fa-life-ring"></i>
						</div>
					</div>
					<div class="widget-summary-col">
						<div class="summary">
							<h4 class="title">Data Karyawan</h4>
							<div class="info">
								<strong class="amount">
									<?php $query = $this->db->query("select * from tbl_kartetap where id_per = '1'");
									echo $query->num_rows(); ?></strong>
							</div>
						</div>
						<div class="summary-footer">
							<a href="<?php echo base_url(); ?>index.php/kartetap" class="text-uppercase">(view all)</a>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<div class="col-md-6 col-xl-12">
		<section class="panel">
			<div class="panel-body bg-secondary">
				<div class="widget-summary">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon">
							<i class="fa fa-life-ring"></i>
						</div>
					</div>
					<div class="widget-summary-col">
						<div class="summary">
							<h4 class="title">Data Gaji Karyawan</h4>
							<div class="info">
								<strong class="amount"><?php $query = $this->db->query("select * from tbl_gaji");
														echo $query->num_rows(); ?></strong>
							</div>
						</div>
						<div class="summary-footer">
							<a href="<?php echo base_url(); ?>index.php/gaji_karyawan" class="text-uppercase">(view all)</a>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
</div>

