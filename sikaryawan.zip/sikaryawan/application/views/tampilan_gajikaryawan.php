<!-- start: page -->
<section class="panel">
    <header class="panel-heading">
        <div class="panel-actions">
            <a href="#" class="fa fa-caret-down"></a>
            <a href="#" class="fa fa-times"></a>
        </div>
        <h2 class="panel-title"><?php echo $judul; ?></h2>
    </header>

    <div class="panel-body">

        <div class="flash-data" data-flashdata="<?php echo $this->session->flashdata('info'); ?>"></div>

        <?php if ($this->session->flashdata('info')) : ?>

        <?php endif; ?>
        
        <table class="table table-bordered table-striped mb-none" id="tabel_gaji">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Tanggal Kontrak</th>
                    <th hidden>Gaji Pokok</th>
                    <th hidden>Gaji Insentif</th>
                    <th>Tanggal Terima</th>
                    <th>Jumlah Gaji</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php foreach ($gaji as $gj) :
                    $tgl = date('Y-m-d');
                    $tgl_mulai = $gj['mulai_bekerja'];
                    $tgl_terima = $gj['tgl_terima'];
                    $tgl_terima2 = date('Y-m-01', strtotime('+1 months', strtotime($tgl_terima)));
                    // 30 hari setelah tanggal mulai kerja

                    ?>

                    <tr>
                        <td><?= $i; ?></td>
                        <td><?= $gj['nama_kartetap']; ?></td>
                        <td><?= $gj['mulai_bekerja']; ?></td>
                        <td hidden>Rp. <?= number_format($gj['g_pokok'], 0, ',', '.'); ?>,-</td>
                        <td hidden>Rp. <?= number_format($gj['g_insentif'], 0, ',', '.'); ?>,-</td>
                        <td>
                            <?php
                            echo $tgl_terima;
                            ?>
                        </td>

                        <td>Rp. <?= number_format($gj['g_pokok'], 0, ',', '.'); ?>,-</td>

                        <td>
                            <a href="<?php echo base_url(); ?>index.php/gaji_karyawan/bayar_gaji/<?= $gj['id_kartetap']; ?>/<?= $gj['tgl_terima']; ?>/<?php echo $gj['id_gaji']; ?>" class="btn btn-danger" <?php if ($tgl != $tgl_terima) {
                                                                                                                                                                                                                echo "disabled";
                                                                                                                                                                                                            } ?>><i class="fa fa-edit"></i> Bayar</a>

                            <a href="<?php echo base_url(); ?>index.php/gaji_karyawan/slip_gaji/<?php echo $gj['id_gaji']; ?>" class="btn btn-warning"><i class="fa fa-print"></i> Slip</a>
                        </td>

                    </tr>

                    <?php $i++; ?>
                <?php endforeach; ?>

            </tbody>
        </table>
    </div>
</section>