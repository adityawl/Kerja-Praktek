<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kartetap extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		if (!$this->session->userdata('username')) {
			redirect('login');
		}

		$this->load->model('model_kartetap');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$isi['kartep'] 		= $this->model_kartetap->listing();
		$isi['content'] 	= 'tampilan_kartetap';
		$isi['judul']		= 'Data Karyawan';
		$isi['sub_judul'] 	= 'Data Karyawan';
		$this->load->view('tampilan_beranda', $isi);
	}

	public function tambah()
	{
		$isi['content'] = 'tambah_kartetap';
		$isi['judul']	= 'Data Karyawan';
		$isi['sub_judul'] = 'Data Karyawan';
		$isi['jabatan']	= $this->model_kartetap->getjabatan();
		$this->load->view('tampilan_beranda', $isi);
	}

	public function edit($id_kartetap)
	{
		$isi['content'] = 'edit_kartetap';
		$isi['judul']	= 'Ubah Data Karyawan';
		$isi['sub_judul'] = 'Data Karyawan';
		$isi['data']	= $this->model_kartetap->listing();
		$isi['data2']	= $this->model_kartetap->getjabatan();
		$isi['data3']	= $this->model_kartetap->detail($id_kartetap);
		$this->load->view('tampilan_beranda', $isi);
	}

	public function perpanjang($id_kartetap)
	{
		$isi['content'] = 'perpanjang_kar';
		$isi['judul']	= 'Masa Kontrak Karyawan';
		$isi['sub_judul'] = 'Masa Kontrak Karyawan';
		$isi['data']	= $this->model_kartetap->listing();
		$isi['data3']	= $this->model_kartetap->detail($id_kartetap);
		$this->load->view('tampilan_beranda', $isi);
	}

	public function tambah_gaji($id_kartetap)
	{
		$isi['content'] = 'tambah_gaji';
		$isi['judul']	= 'Gaji Karyawan';
		$isi['sub_judul'] = 'Gaji Karyawan';
		$isi['data2']	= $this->model_kartetap->getjabatan();
		$isi['data3']	= $this->model_kartetap->detail($id_kartetap);
		$this->load->view('tampilan_beranda', $isi);
	}

	public function save()
	{

		$tetap  = array(
			'nama_kartetap' 	=> strip_tags($this->input->post('namakar', true)),
			'nama_jbtn'			=> $this->input->post('jabatan', true),
			'mulai_bekerja' 	=> $this->input->post('mulaibekerja', true),
			'status' 			=> $this->input->post('status', true),
			'habis_masa_kontrak' => $this->input->post('habis', true),
			'status_gaji' 		=> $this->input->post('status_gaji', true),
			'id_per'			=> 1
		);

		$insert = $this->model_kartetap->simpan($tetap);

		if ($insert) {
			$this->session->set_flashdata('info', 'Di Simpan');
			redirect('kartetap');
		} else {
			$this->session->set_flashdata('info', 'Data Tidak Berhasil di Simpan');
			redirect('kartetap');
		}
	}

	public function save_perpanjang()
	{
		$id_kartetap = strip_tags($this->input->post('id_kartetap'));

		$tetap  = array(
			'habis_masa_kontrak' 	=> $this->input->post('habis')
		);

		$where = array(
			'id_kartetap' => $id_kartetap
		);

		$insert = $this->model_kartetap->perpanjang($where, $tetap, 'tbl_kartetap');

		$this->session->set_flashdata('info', ' Di Perpanjang');
		redirect('kartetap');
	}

	public function save1()
	{
		$id_kartetap = $this->input->post('id_kartetap');

		$tetap  = array(
			'nama_kartetap' 		=> strip_tags($this->input->post('namakar')),
			'nama_jbtn'				=> $this->input->post('jabatan'),
			'mulai_bekerja' 		=> $this->input->post('mulaibekerja'),
			'status' 				=> $this->input->post('status'),
			
		);

		$where = array(
			'id_kartetap' => $id_kartetap
		);

		$insert = $this->model_kartetap->edit($where, $tetap, 'tbl_kartetap');

		$this->session->set_flashdata('info', ' Di Ubah');
		redirect('kartetap');
	}


	public function tambahgaji()
	{

		// mengupdate status gaji jadi 1
		$id_kartetap = $this->input->post('id_kartetap');

		$tetap  = array(
			'status_gaji' 		=> 1,
		);

		$where = array(
			'id_kartetap' => $id_kartetap
		);

		$insert = $this->model_kartetap->edit($where, $tetap, 'tbl_kartetap');

		// memasukkan data gaji
		$gaji  = array(
			'id_kartetap' 		=> strip_tags($this->input->post('id_kartetap', true)),
			'g_pokok' 			=> $this->input->post('g_pokok', true),
			'tgl_terima'		=> $this->input->post('tgl_terima', true),
			'status_bayar'		=> '0'
		);

		$insert = $this->model_kartetap->simpan_gaji($gaji);

		if ($insert) {
			$this->session->set_flashdata('info', 'Di Simpan');
			redirect('kartetap');
		} else {
			$this->session->set_flashdata('info', 'Data Tidak Berhasil di Simpan');
			redirect('kartetap');
		}
	}


	public function hapus($id_kartetap)
	{
		$data = array('id_kartetap' => $id_kartetap);
		$this->model_kartetap->hapus($data);
		$this->model_kartetap->hapus_gaji($data);
		$this->session->set_flashdata('info', ' , Data Telah Dihapus');
		redirect('kartetap');
	}
}
