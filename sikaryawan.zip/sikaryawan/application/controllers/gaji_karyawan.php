<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Gaji_karyawan extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		if (!$this->session->userdata('username')) {
			redirect('login');
		}

		$this->load->model('model_gajikaryawan', 'gaji');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$isi['gaji'] 		= $this->gaji->getdata();
		$isi['content'] 	= 'tampilan_gajikaryawan';
		$isi['judul']		= 'Data Gaji Karyawan';
		$isi['sub_judul'] 	= 'Gaji Karyawan';
		$this->load->view('tampilan_beranda', $isi);
	}

	public function slip_gaji($id_gaji)
	{
		$isi['content'] = 'slip/slip_gaji';
		$isi['judul']	= 'Data Slip Gaji';
		$isi['sub_judul'] = 'Karyawan Tetap';
		$isi['data']	= $this->gaji->getdatabyid($id_gaji);
		$this->load->view('tampilan_beranda', $isi);
	}

	public function print($id_gaji)
	{
		$isi['data']	= $this->gaji->getdatabyid($id_gaji);
		$this->load->view('slip/slip_gaji_print', $isi);
	}

	public function bayar_gaji($id_kartetap, $tgl_terima, $id_gaji)
	{
		$id = $id_gaji;
		$id_karyawan2 = $id_kartetap;
		$tgl = $tgl_terima;
		$tgl_baru = date('Y-m-01', strtotime('+1 months', strtotime($tgl)));

		$data = array(
			'status_bayar'  => 1,
			'tgl_terima'	=> $tgl_baru
		);

		$this->db->set($data);
		$this->db->where('id_gaji', $id);
		$this->db->update('tbl_gaji');

		$data2 = [
			'id_gaji' 		=> $id,
			'id_kartetap'	=> $id_karyawan2,
			'tgl_terima' 	=> date('Y-m-d'),
			'status_gaji' 	=> 1,
		];

		$this->db->insert('tbl_riwayatgaji', $data2);

		$this->session->set_flashdata('info', 'Sudah di bayarkan');
		redirect('riwayat_gaji');
	}
}
