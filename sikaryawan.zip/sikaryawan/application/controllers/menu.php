<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {

	public function index()
	{
		$data = array ('title'	=> 'sdas',
					   'isi'	=> 'index.php/tes'
					);
		$this->load->view('tampilan_beranda',$data, FALSE);
	}

}

/* End of file menu.php */
/* Location: ./application/controllers/menu.php */