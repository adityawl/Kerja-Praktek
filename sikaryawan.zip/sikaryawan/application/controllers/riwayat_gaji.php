<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Riwayat_gaji extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('username')) {
            redirect('login');
        }

        $this->load->model('model_gajikaryawan', 'gaji');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $isi['content']     = 'riwayat/tampil_riwayat';
        $isi['judul']        = 'Data Riwayat Gaji Karyawan';
        $isi['sub_judul']     = 'Gaji Karyawan';
        $isi['data']        = $this->gaji->getriwayat();
        $this->load->view('tampilan_beranda', $isi);
    }

    public function detail($id_gaji)
    {
        $isi['content']     = 'riwayat/tampil_detail';
        $isi['judul']        = 'Detail Riwayat Gaji Karyawan';
        $isi['sub_judul']     = 'Gaji Karyawan';
        $isi['detail']        = $this->gaji->detail($id_gaji);
        $this->load->view('tampilan_beranda', $isi);
    }
}
