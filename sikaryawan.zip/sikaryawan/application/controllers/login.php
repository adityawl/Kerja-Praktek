<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{

	public function index()
	{
		$this->load->view('tampilan_login');
	}

	public function getlogin()
	{
		$username = strip_tags(str_replace("'", "", $this->input->post('username')));
		$password = strip_tags(str_replace("'", "", $this->input->post('password')));
		$this->load->model('model_login');
		$this->model_login->getlogin($username, $password);
	}

	public function logout()
	{
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('password');

		$this->session->set_flashdata('info', '<div class="alert alert-success" role="alert"> Anda berhasil Logout . </div>');
		redirect('login');
	}
}

/* End of file login.php */
/* Location: ./application/controllers/login.php */
